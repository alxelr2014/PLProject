def temp(x = 4 , y = 10):
    return x - y;
    print(2);;

z = temp( 3 );
print(z,  [temp(4,6), 2 - 3], 0, True or False, None);