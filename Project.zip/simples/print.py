hi = 2;
hi = hi + 3;
print(hi , hi - 5.5);