z = True or False;
y = True and False;
x = y and z or True;

print(z, y ,x);
