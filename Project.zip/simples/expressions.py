z = - 2;
print(1, z, 1);