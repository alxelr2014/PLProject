hi = 2;
if False:
    hi = hi + 3;
else:
    hi = hi - 2;;
print(hi);